# Meals Catalogue - Submission 01

Dicoding Menjadi Flutter Developer Expert

## Challenge

- Daftar Makanan
  - Syarat :
    - Menggunakan GridView untuk menampilkan daftar makanan.
- Detail Makanan
  - Syarat :
    - Menampilkan gambar, nama makanan dan informasi bahan makanan pada halaman detail makanan.
- Teknis
  - Menerapkan mekanisme Navigator.push()

## Author

goeroeku

## Requirement

- Flutter
- Android SDK & Emulator

## Run

```sh
flutter run
```

## Build Android

```sh
flutter build apk
```