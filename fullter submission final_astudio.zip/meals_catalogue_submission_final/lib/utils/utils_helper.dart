class UtilsHelper {
  static final String apiUrl = "https://www.themealdb.com/api/json/v1/1/";
}
