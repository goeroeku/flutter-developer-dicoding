import 'package:meals_catalogue/models/recipe.dart';

class Favorite {
  Recipe recipe;
  bool isFavorite;

  Favorite({this.recipe, this.isFavorite});
}
